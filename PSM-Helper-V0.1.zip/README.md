A Chrome extension, not interesting for people other than me.
